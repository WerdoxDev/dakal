<template>
  <div class="flex flex-col justify-center items-center p-2 border border-gray-200 rounded-lg shadow-lg w-max gap-y-2 bg-gray-300">
    <div class="flex items-center w-full gap-x-2">
      <div class="w-12 h-12 md:w-16 md:h-16 rounded-lg bg-gray-500" />
      <div class="flex flex-col justify-center gap-y-1">
        <div class="bg-gray-400 w-20 h-5 rounded-lg" />
        <div class="bg-gray-400 w-20 h-5 rounded-lg" />
      </div>
    </div>
    <div class="bg-gray-400 w-full h-8 rounded-lg" />
  </div>
</template>
